<script>
import Vue from 'vue';
// Uncomment import and local "components" registration if library is not registered globally.
// import { TestLibSample } from '@/entry.esm';

export default Vue.extend({
  name: 'ServeDev',
  // components: {
  //  TestLibSample,
  // }
});
</script>

<template>
  <div id="app">
    <test-lib-sample />
  </div>
</template>

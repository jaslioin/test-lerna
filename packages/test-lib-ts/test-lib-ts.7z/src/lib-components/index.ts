/* eslint-disable import/prefer-default-export */
export { default as TestLibTsSample } from './test-lib-ts-sample';
export { default as TestA } from './test-a';

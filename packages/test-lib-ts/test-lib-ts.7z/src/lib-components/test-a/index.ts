/* eslint-disable import/prefer-default-export */
export { default as default } from './test-a.vue';

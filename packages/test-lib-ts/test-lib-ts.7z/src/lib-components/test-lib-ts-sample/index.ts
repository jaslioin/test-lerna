/* eslint-disable import/prefer-default-export */
export { default as default } from './test-lib-ts-sample.vue';

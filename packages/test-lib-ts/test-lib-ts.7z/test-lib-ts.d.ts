import Vue, { PluginFunction, VueConstructor } from 'vue';


declare const TestLibTs: PluginFunction<any>;
export default TestLibTs;

export const TestLibTsSample: VueConstructor<Vue>;
